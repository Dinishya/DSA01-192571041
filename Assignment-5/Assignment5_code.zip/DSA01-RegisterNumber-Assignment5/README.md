# DSA01 Assignment 5 (CO5) - Reliable software with runtime polymorphism and exceptions

Name: <your name>
Register number: <your register number>
Compiler: g++ 13.3.0 (check yours with `g++ --version`)
Compile command: `g++ -std=c++17 -Wall -Wextra file.cpp -o file`
Timing runs add `-O2`; sanitizer runs add `-fsanitize=address,undefined -g`.

## How to run
- Task_A2_predict: `a2_predict.cpp` (as given), `a2_novdtor.cpp` (no virtual destructor; build with ASan), `a2_novdtor_member.cpp` (adds a std::string member so ASan shows the problem)
- Task_A5_predict: `a5_predict.cpp`
- Task_B1: `b1_complete.cpp` (Complete the Code); `b1_nonvirtual.cpp`; `b1_err_a.cpp` / `b1_err_c.cpp` (expected compile errors); `b1_novdtor.cpp` (ASan: new-delete-type-mismatch)
- Task_B2: `b2_predict.cpp`, `b2_complete.cpp`, `b2_throw_e.cpp`, `b2_slice_throw*.cpp` (throw; vs throw e;)
- Task_B3: `bench.cpp` and `bench_err.cpp` (compile with -O2)
- Task_B4: `billing_main.cpp` with `billing.h` and `extension.h`. Sanitizer build: add `-DSKIP_BAD_ALLOC` (ASan's operator new aborts instead of throwing bad_alloc)

## Result of each task
Fill in after running on your own machine (copy the outputs and add screenshots to each task folder).
